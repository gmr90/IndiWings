<!DOCTYPE html>

<html>

	<head>
		<meta charset = "utf-8">
		<title>IndiWW</title>
		<link rel="stylesheet" href="CSS/prc1.css" />
	</head>
	
	<body>
	<div class="container">
		<header class="top">
						<img src="IMAGES\pic1.png" alt="Logo" class="logo" /></br></br>
						<h1>Indi Wings</h1>
						<img src="IMAGES\pic2.jpg" alt="bld" class="bld"/>
	
						<div class="address">
							
							<span class="store-title">Lee'S Summit,MO</span>
							<br>
							 <span class="store-adr">
								NW Chipman Road<br>
								816-666-0000
							</span><br>
							<a href="https://www.google.com/maps/dir//NW+Chipman+Rd,+Lee's+Summit,+MO/@38.9265396,-94.4193292,17z/data=!4m13!1m4!3m3!1s0x87c0e03e70ec15f9:0xb229aca95a2ca656!2sNW+Chipman+Rd,+Lee's+Summit,+MO!3b1!4m7!1m0!1m5!1m1!1s0x87c0e03e70ec15f9:0xb229aca95a2ca656!2m2!1d-94.4171405!2d38.9265396" style ="color:white"title="get direction to this store">Get Direction</a>
						</div>
						<nav class="page_nav">
									<ul>
												<li> <a	href="prh1.php">Home				</a></li>
												<li> <a	href="ContactUs.php">Reach Us		</a></li>				
												<li> <a	href="req.php">Cook Book</a></li>
												<li> <a	href="FeedBack.php">FeedBack</a></li>
									</ul>					
						</nav>
						<div class="clear"></div>
				</header>
				<section class="section">
				<div style="height:300px;" class="tableContainer">
				
		
			
			<img style="margin-left:120px;" src="IMAGES/thanks.jpg"  alt="Smiley face"  height="298px" width="700px">
			
			
		
		</div>
		</section>
		<footer class="page_footer">
					&copy; copyright IndiWings.com
				</footer>
	</div>			
	</body>

</html>