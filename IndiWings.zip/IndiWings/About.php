<!DOCTYPE html>

<html>

	<head>
		<meta charset = "utf-8">
		<title>IndiWW Home</title>
		<link rel="stylesheet" href="CSS/prc1.css" />
		
	</head>
	
	<body>
				<div class="container">
				
				<header class="top">
						<img src="IMAGES\logo.JPG" alt="Logo" class="logo" />
						
						<nav class="page_nav">
									<ul>
												<li> <a	href=" ">Home				</a></li>
												<li> <a	href=" ">About Us		</a></li>				
												<li> <a	href=" ">Products		</a></li>
												<li> <a	href=" ">Contact Us	</a></li>																											
									</ul>					
						</nav>
						<div class="clear"></div>
				</header>
				
				<section class="section">
						<div>			
							<h1><font color="black">About Us!!!</font></h1>
								<div>
									<font color="#666666">
										
										This page is all about
								
									</font>								
								</div>
						</div>				
				</section>

				<footer class="page_footer">
					&copy; copyright abcd.com
				</footer>
				
				</div>				
	</body>
	
</html>
